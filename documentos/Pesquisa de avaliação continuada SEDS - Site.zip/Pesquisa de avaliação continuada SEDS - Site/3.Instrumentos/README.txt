Este arquivo README foi gerado em 09/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título dos Conjuntos de Dados: 
•	H25_BancoDeDados_Avaliação_CursosDHAtividadePolicial_2009
•	H25_2_BancoDeDados_Avaliação_CursosDH_AtividadePolicial_2009
Informações do(s) pesquisador(es): 
	Nome: Simone Santos
Instituição: 
Email: 
Nome: Lívia Henriques
Instituição: 
Email:
Nome: Aline Nogueira
Instituição: 
Email: 
Nome: Cynthia Semíramis
Instituição: 
Email: 
Nome: Rodrigo Alisson Fernandes
Instituição: Universidade Federal de Minas Gerais
Email: rodrigopesquisa@gmail.com
Nome: Luís Felipe Zilli
Instituição: Fundação João Pinheiro
Email: felipe.zilli@fjp.mg.gov.br

Data de coleta dos dados: 2008
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: Secretária de Estado de Defesa Social

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
SANTOS, Simone; HENRIQUES, Lívia; NOGUEIRA, Aline; SEMÍRAMIS, Cynthia; FERNANDES, Rodrigo Alisson; ZILLI, Luís Felipe. H25_BancoDeDados_Avaliação_CursosDHAtividadePolicial_2009; [Conjunto de dados: Online]. Data de coleta dos dados: 2008. Universidade Federal de Minas Gerais, 2024. Disponível em: <link>. Acesso em: .

SANTOS, Simone; HENRIQUES, Lívia; NOGUEIRA, Aline; SEMÍRAMIS, Cynthia; FERNANDES, Rodrigo Alisson; ZILLI, Luís Felipe. H25_2_BancoDeDados_Avaliação_CursosDH_AtividadePolicial_2009. [Conjunto de dados: Online]. Data de coleta dos dados: 2008. Universidade Federal de Minas Gerais, 2024. Disponível em: <link >. Acesso em: 

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Grupos focais e questionário por telefone
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Robson Sávio Reis Souza, Simone Santos, Lívia Henriques, Aline Nogueira, Cynthia Semíramis, Rodrigo Alisson Fernandes, Luís Felipe Zilli

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H25_BancoDeDados_Avaliação_CursosDH_AtividadePolicial_2009
Número de variáveis: 586
Número de casos/linhas: 54
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H25_2_BancoDeDados_Avaliação_CursosDH_AtividadePolicial_2009
Número de variáveis: 37
Número de casos/linhas: 25
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”



