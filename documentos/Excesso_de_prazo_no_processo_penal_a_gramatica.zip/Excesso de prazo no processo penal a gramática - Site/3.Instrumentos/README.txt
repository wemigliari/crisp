Este arquivo README foi gerado em 09/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H5_Base excesso de prazo 
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com

Data de coleta dos dados: 01/2018
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: CNPq

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
RIBEIRO, Ludmila. H5_Base excesso de prazo. [Conjunto de dados: Online]. Data de coleta dos dados: 01/2018. Universidade Federal de Minas Gerais, 2024. Disponível em: <link>. Acesso em: .

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Raspagem de dados nos acórdãos do Supremo Tribunal Federal indexados a partir da categoria “excesso de prazo
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Ludmila Ribeiro

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H5_Base excesso de prazo 
Número de variáveis: 1730
Número de casos/linhas: 57
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”


