Este arquivo README foi gerado em 10/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H7_piep
Informações do(s) pesquisador(es): 
	Nome: Ana Beraldo
Instituição: Universidade Federal de São Carlos 
Email: anaberaldopsi@gmail.com 
Nome: Isabela Cristina Araújo
Instituição: Universidade Federal de São Carlos
Email: isabelacristina1903@gmail.com
Nome: Natália Martino
Instituição: Universidade Federal de Minas Gerais
Email: natymartino@gmail.com
Nome: Renata Mauro
Instituição: 
Email: 

Data de coleta dos dados: 07/2017 – 02/2018
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: FAPEMIG

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
BERALDO, Ana; ARAÚJO, Isabela Cristina; MARTINO, Natália; MAURO, Renata. H7_piep. [Conjunto de dados: Online]. Data de coleta dos dados: 07/2017 – 02/2018. Universidade Federal de São Carlos, Universidade Federal de Minas Gerais. Disponível em: <link>. Acesso em: 

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Pesquisa amostral interseccional (Survey)
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Ana Beraldo, Isabela Cristina Araújo, Natália Martino, Renata Mauro, Ana Rita Nascimento, Cláudia Drumond, Gabriela Scarpelli, Maria Luiza Brasil, Renann Paolinelli, Taís Lima da Silva, Taís Melo

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H7_piep 
Número de variáveis: 163
Número de casos/linhas: 170
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
