pacman::p_load(tidyverse,haven,readxl,here,rgdal,sf,openxlsx)

caminho_do_arquivo_sav <- "E:/Pesquisas - Site/Missão Guardar/2.Banco de dados/Base completa_2.sav"
df <- read_sav(caminho_do_arquivo_sav)

df[1:30] <- NULL
substituir_NA_datas <- function(data) {
  datas <- sapply(data, function(x) inherits(x, "Date"))
  data[ , datas] <- lapply(data[ , datas], function(x) {
    x[is.na(x)] <- as.Date("9999-12-31")
    return(x)
  })
  
  return(data)
}

for (col in names(df)) {
  if (inherits(df[[col]], "Date")) {
    df[[col]] <- format(df[[col]], "%d/%m/%Y")
  }
}

for (col in names(df)) {
  if (is.character(df[[col]]) || is.factor(df[[col]])) {
    df[[col]][df[[col]] == ""] <- NA
  }
}

# Função para substituir NA por 99 em colunas numéricas
substituir_NA_numericas <- function(data) {
  numericas <- sapply(data, is.numeric)
  data[, numericas][is.na(data[, numericas])] <- 99
  return(data)
}

# Função para substituir NA por "Não se aplica" em colunas de caracteres
substituir_NA_caracteres <- function(data) {
  caracteres <- sapply(data, is.character)
  data[, caracteres][is.na(data[, caracteres])] <- "Não se aplica"
  return(data)
}

df <- substituir_NA_datas(df)
for (col in names(df)) {
  if (inherits(df[[col]], "Date")) {
    df[[col]] <- format(df[[col]], "%d/%m/%Y")
  }
}

df <- substituir_NA_caracteres(df)
df <- substituir_NA_numericas(df)

transformar_double_em_numeric <- function(df) {
  df[] <- lapply(df, function(x) {
    if (is.double(x)) {
      as.numeric(x)  # Converte para numeric (se necessário)
    } else {
      x  # Mantém as colunas não double
    }
  })
  return(df)
}

df <- transformar_double_em_numeric(df)

df <- df %>% select(where(~! is.character(.)))
df[1:12] <- lapply(df[1:12], as.numeric)

write_sav(df, "E:/Pesquisas - Site/Missão Guardar/2.Banco de dados/H6_MissaoGuardar.sav")
write.xlsx(df, "E:/Pesquisas - Site/Missão Guardar/2.Banco de dados/H6_MissaoGuardar.xlsx")

