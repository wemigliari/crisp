Este arquivo README foi gerado em 22/10/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H16_Base de dados_2
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: lmlr@ufmg.br
Nome: Valéria Oliveira
Instituição: Universidade Federal de Minas Gerais
Email: valcrisoli@ufmg.br
Nome: Alexandre M. A. Diniz
Instituição: Pontifícia Universidade Católica de Minas Gerais (PUC)
Email: alexandrediniz@pucminas.br
Data de coleta dos dados: 
Localização geográfica da coleta de dados: Brasil
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: 

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
RIBEIRO, Ludmila; OLIVEIRA, Valéria; DINIZ, Alexandre M. A. H16_Base de dados_2. Belo Horizonte: Universidade Federal de Minas Gerais e Pontifícia Universidade Católica de Minas Gerais, 2024. Público. Disponível em: <link>. Acesso em:.

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Mesclagens de base secundárias
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: 
H16_Base de dados_2
Número de variáveis: 156
Número de casos/linhas: 675
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”

