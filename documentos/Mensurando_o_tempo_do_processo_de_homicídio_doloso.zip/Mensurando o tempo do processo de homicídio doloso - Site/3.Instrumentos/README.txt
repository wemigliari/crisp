Este arquivo README foi gerado em 30/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H22_Bancotempohomicidios 
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com
Nome: Vinícius Assis Couto
Instituição: Universidade Federal de Minas Gerais
Email: viniccouto@gmail.com
Nome: Fernanda Bestetti de Vasconcellos
Instituição: Pontifícia Universidade Católica do Rio Grande do Sul
Email: fevasconcellos@hotmail.com
Nome: Jaime Luiz Cunha de Souza
Instituição: Universidade Federal do Pará 
Email: jaimecunha@ufpa.br
Nome: José Luiz Ratton
Instituição: Universidade Federal de Pernambuco
Email: jl.ratton@gmail.com
Nome: Michele Cunha Franco
Instituição: Universidade Federal de Goiás
Email: mcfrancojur@gmail.com

Data de coleta dos dados: 2014
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: FUNDEP

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
RIBEIRO, Ludmila; COUTO, Vinícius Assis; VASCONCELLOS, Fernanda Bestetti de; SOUZA, Jaime Luiz Cunha de; RATTON, José Luiz; FRANCO, Michele Cunha. H22_Bancotempohomicidios. [Conjunto de dados: Online]. Data de coleta dos dados: 2014. Universidade Federal de Minas Gerais, Pontifícia Universidade Católica do Rio Grande do Sul, Universidade Federal do Pará, Universidade Federal de Pernambuco, Universidade Federal de Goiás, 2024. Disponível em: <link>. Acesso em: .

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Amostragem Aleatória Simples
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Camila Carvalho, Célio de Assis Picanço Filho, Débora Rodrigues, Ellen Caroline dos Santos Silva, Eros Caio de Souza, Gilson Antunes, Luísa Duque Belfort de Oliveira, Marcilaine Martins da Silva Oliveira, Marcos Cristiano dos Reis, Simone Schuck da Silva, Tamires Garcia, Flávia Soares, Isadora Dias, Natália Maria Catão Vilela, Nathalia Mourão, Sara Prado, Victor Neiva e Oliveira, Yolanda Campos, Lucas Caetano, Taléia Tartari, Michele Macena 
INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: 
H22_Bancotempohomicidios 
Número de variáveis: 431
Número de casos/linhas: 786
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
