Este arquivo README foi gerado em 24/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H21_visitascompleto
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com
Nome: Julita Lemgruber
Instituição: Centro de Estudos de Segurança e Cidadania da Universidade Candido Mendes, CESeC/UCAM
Email: ludmila.ribeiro@gmail.com
Data de coleta dos dados: 2007 – 2012
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: Department for International Development (DFID, UK)
INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Sim.
Citação recomendada para este conjunto de dados:
RIBEIRO, Ludmila; LEMGRUBER, Julita. H21_visitascompleto. [Conjunto de dados: Online]. Data de coleta dos dados: 2007 – 2012. Universidade Federal de Minas Gerais, Centro de Estudos de Segurança e Cidadania (CESeC/UCAM), 2024. Disponível em: <link >. Acesso em: 

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Pesquisa amostral interseccional (Survey)
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H21_visitascompleto 
Número de variáveis: 71
Número de casos/linhas: 179275
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
