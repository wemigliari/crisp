Este arquivo README foi gerado em 02/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H23_BaseDeDados_MeioAberto_2008
Informações do(s) pesquisador(es): 
Nome: Frederico Couto Marinho
Instituição: Universidade Federal de Minas Gerais
Email: fredericocouto@ufmg.br
Nome: Cristiane Kasuko Torisu
Instituição: Agência Espacial Brasileira
Email:
Nome: Klarissa Almeida Silva
Instituição: Universidade Federal Fluminense
Email: klarissaplatero@id.uff.br
Nome: Diogo Alves Caminhas
Instituição: Universidade Federal de Minas Gerais
Email: diogocaminhas@gmail.com
Nome: Braúlio Alves Figueireido Silva
Instituição: Escola Nacional de Administração Pública – Enap
Email: braulio.fas@gmail.com

Data de coleta dos dados: 2008 – 2009
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: FAPEMIG

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
MARINHO, Frederico Couto; TORISU, Cristiane Kasuko; SILVA, Klarissa Almeida; CAMINHAS, Diogo Alves; SILVA, Braúlio Alves Figueireido. H23_BaseDeDados_MeioAberto_2008. [Conjunto de dados: Online]. Data de coleta dos dados: 2008 – 2009. Local de coleta: Minas Gerais. Universidade Federal de Minas Gerais, 2024. Disponível em: <link >. Acesso em:.

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Entrevistas semi-estruturadas e Pesquisa amostral interseccional (Survey)
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Mateus Rennó; Michael Abrãao Soares Miranda; Danilo Brasil Soares; Aline Nogueira Menezes Mourão; Luiza Lobato Andrade; José Nery; Simone Viana; Daniele Viana.

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H23_BaseDeDados_MeioAberto_2008
Número de variáveis: 204
Número de casos/linhas: 125
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
