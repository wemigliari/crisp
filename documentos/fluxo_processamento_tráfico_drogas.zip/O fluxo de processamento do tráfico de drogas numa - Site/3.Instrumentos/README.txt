Este arquivo README foi gerado em 25/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H20_Documentos e indiciados (agosto)_3
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com
Nome: Daniely Reis
Instituição: Universidade Federal de Minas Gerais
Email:
Data de coleta dos dados: 2007 – 2017
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: CNPq

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
Ribeiro, L., & Reis, D. (2024). H20_Documentos e indiciados (agosto)_3. Universidade Federal de Minas Gerais. Disponível em (link). Dados coletados entre 2007 e 2017 em Minas Gerais. Financiado pelo CNPq. Acesso em:

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Amostra aleatória da base de dados sobre tráfico de drogas do Tribunal de Justiça de Minas Gerais
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: 
H20_Documentos e indiciados (agosto)_3
Número de variáveis: 211
Número de casos/linhas: 1495
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
