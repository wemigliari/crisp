Este arquivo README foi gerado em 04/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H4_BancoMedoVitimizacaoContagem2011v4_TRATADO
Informações do(s) pesquisador(es): 
Nome: Braúlio Alves Figueireido Silva
Instituição: Escola Nacional de Administração Pública – Enap
Email: braulio.fas@gmail.com
Nome: Diogo Alves Caminhas
Instituição: Universidade Federal de Minas Gerais
Email: diogocaminhas@gmail.com
Nome: Frederico Couto Marinho
Instituição: Universidade Federal de Minas Gerais
Email: fredericocouto@ufmg.br
Nome: Karina Rabelo Leite Marinho
Instituição: Fundação João Pinheiro
Email: karina.rabelo@fjp.mg.gov.br
Nome: Lívia Henriques de Oliveira
Instituição: 
Email: 
Nome: Mateus Rennó Santos 
Instituição: University of South Florida
Email: rennosantos@usf.edu
Nome: Rodrigo Alisson Fernandes
Instituição: Universidade Federal de Minas Gerais
Email: rodrigopesquisa@gmail.com
Nome: Vinícius Assis Couto
Instituição: Escritório sobre Drogas e Crime das Nações Unidas
Email: viniccouto@gmail.com

Data de coleta dos dados: 2009
Localização geográfica da coleta de dados: Contagem Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: Secretária Municipal de Defesa Social de Contagem

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
SILVA, Braúlio Alves Figueireido; CAMINHAS, Diogo Alves; MARINHO, Frederico Couto; MARINHO, Karina Rabelo Leite; OLIVEIRA, Lívia Henriques de; SANTOS, Mateus Rennó; FERNANDES, Rodrigo Alisson; COUTO, Vinícius Assis. H4_BancoMedoVitimizacaoContagem2011v4_TRATADO. [Conjunto de dados: Online]. Data de coleta dos dados: 2009. Local de coleta: Contagem, Minas Gerais. Universidade Federal de Minas Gerais, 2024. Disponível em: <link>. Acesso em: 


VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Pesquisa amostral interseccional (Survey)
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Aline Nogueira Menezes Mourão; Danilo Assis Brasil; Luiza Lobato Andrade

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: H4_BancoMedoVitimizacaoContagem2011v4_TRATADO
Número de variáveis: 368
Número de casos/linhas: 115
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
