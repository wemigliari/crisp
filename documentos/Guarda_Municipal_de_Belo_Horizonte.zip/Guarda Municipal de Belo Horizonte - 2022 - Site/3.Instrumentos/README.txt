Este arquivo README foi gerado em 14/10/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H12_guarda_municipal_bh_2022
Informações do(s) pesquisador(es): 
Nome: Claudio Chaves Beato Filho
Instituição: Universidade Federal de Minas Gerais
Email: claudiobeato.filho@gmail.com
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com
Nome: Valéria Oliveira
Instituição: Universidade Federal de Minas Gerais
Email: valcrisoli@ufmg.br
Data de coleta dos dados: 09/2020 – 12/2020
Localização geográfica da coleta de dados: Minas Gerais
Informações sobre fontes de financiamento que apoiaram a coleta dos dados: Secretaria Municipal de Segurança e Prevenção (SMSP)

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
BEATO FILHO, Claudio Chaves; RIBEIRO, Ludmila; OLIVEIRA, Valéria. H12_guarda_municipal_bh_2022. 2024. Conjunto de dados. Universidade Federal de Minas Gerais, Secretaria Municipal de Segurança e Prevenção (SMSP). Disponível em: [link]. Acesso em:.

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Pesquisa amostral interseccional (Survey)
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Thais Lemos Duarte, Luana Hordones Chaves, Ana Beraldo, Ariane Gontijo Lopes, Isabela Araújo, Isabella Silva Matosinhos, Lívia Lages, Natália Martino, Taís Lima da Silva

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: 
H12_guarda_municipal_bh_2022
Número de variáveis: 207
Número de casos/linhas: 2138
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
