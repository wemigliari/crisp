Este arquivo README foi gerado em 10/09/2024 por Henrique Galvão Diniz.

INFORMAÇÕES GERAIS
Título do Conjunto de Dados: H7_BANCO_final - 592 questionários
Informações do(s) pesquisador(es): 
	Nome: Ludmila Ribeiro
Instituição: Universidade Federal de Minas Gerais
Email: ludmila.ribeiro@gmail.com
Nome: Victor Neiva e Oliveira
Instituição: Universidade Federal de Minas Gerais
Email: victorneivaeoliveira@yahoo.com.br
Nome: Alexandre Magno Alves Diniz
Instituição: Universidade Federal de Minas Gerais
Email: alexandremadiniz@gmail.com
Data de coleta dos dados: 03/2013 – 04/2014
Localização geográfica da coleta de dados: Belo Horizonte, Minas Gerais

INFORMAÇÕES DE COMPARTILHAMENTO/ACESSO
Licenças/restrições aplicadas aos dados: Público.
Links para publicações que citam ou usam os dados:
Os dados foram derivados de outra fonte? Não.
Citação recomendada para este conjunto de dados:
RIBEIRO, Ludmila; NEIVA E OLIVEIRA, Victor; DINIZ, Alexandre Magno Alves. H7_BANCO_final - 592 questionários. [Conjunto de dados: Online]. Data de coleta dos dados: 03/2013 – 04/2014. Universidade Federal de Minas Gerais, 2024. Disponível em: <link>. Acesso em:

VISÃO GERAL DOS DADOS E ARQUIVOS
Lista de Arquivos: 
Existem várias versões do conjunto de dados? Não.

INFORMAÇÕES METODOLÓGICAS
Descrição dos métodos usados para coleta/geração de dados: Entrevista semiestruturada
Métodos para processamento dos dados:  Por meio do software SPSS
Informações específicas sobre instrumentos ou softwares necessários para interpretar os dados: Recomendável Software R ou SPSS
Pessoas envolvidas na coleta de amostras, processamento, análise e/ou submissão:
Nome: Ludmila Ribeiro, Victor Neiva e Oliveira, Alexandre Magno Alves Diniz

INFORMAÇÕES ESPECÍFICAS DOS DADOS PARA: 
H7_BANCO_final - 592 questionários
Número de variáveis: 134
Número de casos/linhas: 592
Códigos de dados ausentes: Numéricos: 99; 999 Texto: “Não se aplica”. Data: “31/12/9999”
